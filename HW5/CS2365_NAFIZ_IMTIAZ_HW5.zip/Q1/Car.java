
public class Car implements CarbonFootPrint{
	public void getCarbonFootPrint() {
		System.out.println("This message is from Car CarbonFoot");
	}
}