
public class Bicycle implements CarbonFootPrint{
	public void getCarbonFootPrint() {
		System.out.println("This message is from Bicycle CarbonFoot");
	}
}
