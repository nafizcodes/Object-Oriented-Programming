
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CarbonFootPrint carbonfpt;
		Building obj1 = new Building();
		Car obj2 = new Car();
		Bicycle obj3 = new Bicycle();
		
		carbonfpt = obj1;
		
		carbonfpt.getCarbonFootPrint();
		
		carbonfpt = obj2;
		
		carbonfpt.getCarbonFootPrint();
		
		carbonfpt = obj3; 
		
		carbonfpt.getCarbonFootPrint();
		
		
	}
}
