
public interface CarbonFootPrint {
	public void getCarbonFootPrint();
}
