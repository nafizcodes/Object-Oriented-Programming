public class Building implements CarbonFootPrint{
	public void getCarbonFootPrint() {
		System.out.println("This message is from Building CarbonFoot");
	}
}
