
public interface describable {
	String describeShip();
}
