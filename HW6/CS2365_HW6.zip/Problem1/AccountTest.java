/**
   This program demonstrates how the BankAccount
   class constructor throws custom exceptions.
*/

public class AccountTest
{
   public static void main(String [] args)
   {
      // Force a NegativeStartingBalance exception.
      try
      {
         BankAccount account1 =
                     new BankAccount(-100.0);
         
         account1.deposit(200);
         account1.withdraw(500);
 
      }
      catch(NegativeStartingBalance e)
      {
         System.out.println(e.getMessage());
      }
      catch(NegativeDeposit e) 
      {
    	 System.out.println(e.getMessage());
      }
      catch(NegativeWithdraw e) 
      {
    	  System.out.println(e.getMessage());
      } 
      catch (ExcessWithdraw e) {
    	  System.out.println(e.getMessage());
	}
      
      
      //Force a NegativeDeposit exception.
      try
      {
         BankAccount account2 =
                     new BankAccount(100.0);
        
         account2.deposit(-200);   
         account2.withdraw(500);
 
      }
      catch(NegativeStartingBalance e)
      {
         System.out.println(e.getMessage());
      }
      catch(NegativeDeposit e) 
      {
    	 System.out.println(e.getMessage());
      }
      catch(NegativeWithdraw e) 
      {
    	  System.out.println(e.getMessage());
      } 
      catch (ExcessWithdraw e) {
    	  System.out.println(e.getMessage());
	}
      
      
      
      //Force NegativeWithdraw exception
      try
      {
         BankAccount account3 =
                     new BankAccount(100.0);
         
         account3.deposit(200);
         account3.withdraw(-100);
 
      }
      catch(NegativeStartingBalance e)
      {
         System.out.println(e.getMessage());
      }
      catch(NegativeDeposit e) 
      {
    	 System.out.println(e.getMessage());
      }
      catch(NegativeWithdraw e) 
      {
    	  System.out.println(e.getMessage());
      } 
      catch (ExcessWithdraw e) {
    	  System.out.println(e.getMessage());
	}
      
      
      
      //Force ExcessWithdraw exception
      try
      {
         BankAccount account4 =
                     new BankAccount(100.0);
         
         account4.deposit(200);
         account4.withdraw(500000);
 
      }
      catch(NegativeStartingBalance e)
      {
         System.out.println(e.getMessage());
      }
      catch(NegativeDeposit e) 
      {
    	 System.out.println(e.getMessage());
      }
      catch(NegativeWithdraw e) 
      {
    	  System.out.println(e.getMessage());
      } 
      catch (ExcessWithdraw e) {
    	  System.out.println(e.getMessage());
	}
   }
}